<?php
namespace STOMT\StomtFeed\Domain\Model;

/***
 *
 * This file is part of the "STOMTFEEDBACK" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2018 Mariem Bader <bader.mariem1@gmail.com>, STOMT
 *
 ***/

/**
 * Example
 */
class Example extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    }
